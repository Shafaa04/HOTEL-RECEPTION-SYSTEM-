public class Admin {
    private int room;
    private int payment;
    public Admin() {
        room=100;
        payment=80000;
    }
    public Admin(int room) {
        this.room=room;
    }
    public Admin(int room,int payment) {
         this.room=room;
        this.payment=payment;
    }
    public void setRoom() {
        room=room;
    }
    public void getmethod() {
        System.out.println("rooms are "+room+" and each room must be paid "+payment);
    }
} 
class Payment extends Admin {
    private double payment_number;
    public Payment() {
        payment_number = 100.00;
    }
    public void setPayment_number() {
        this.payment_number=payment_number;
    }
    public void getPayment_number() {
        System.out.println("payment number is "+payment_number);
    }
}
class Main {
    public static void main(String[] args) {
        Payment payment=new Payment();
        payment.getPayment_number();
        payment.getmethod();
    }
}