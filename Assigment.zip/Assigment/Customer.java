import java.util.Scanner;
public class Customer extends Receptionist {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your name");
        String name=sc.nextLine();
        System.out.println("Enter your nation");
        String nationality=sc.nextLine();
        System.out.println("Enter your materiality status");
        String materiality=sc.nextLine();
        System.out.println("Enter your phone number");
        int phone=sc.nextInt();
        System.out.println("Enter days that you will stay in our hotel");
        int day=sc.nextInt();
        System.out.println("Enter amount your paid");
        int paid_amount=sc.nextInt();
        System.out.println("Enter number of room");
        int number_room=sc.nextInt();
        int amount=number_room*paid_amount;
        Customer cu=new Customer();
        cu.method1();
        System.out.println("customer name is "+name+" from "+nationality+" nation,relationship status "+materiality+" day that customer will stay in our hotel "+day+" day in room number "+number_room+" amount you suppose to pay "+amount);
    }
}