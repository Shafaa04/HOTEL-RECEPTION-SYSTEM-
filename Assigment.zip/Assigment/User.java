class User  {
    protected String name_employee1="accountant Lameck";
    protected String name_employee2="receptionist Joseph Chacha";
    protected String hotel_name="HOTEL VERDE"; 
}
class Accountant extends User {
    public String accountant_id="ACT123";
    public void method() {
        System.out.println("employee name "+name_employee1);
        System.out.println("name of hotel "+hotel_name);
        System.out.println("employee id is "+accountant_id);
    }
}
class Receptionist extends User {
    public String receptionist_id="REC103";
    public void method1() {
        System.out.println("employee name "+name_employee2);
        System.out.println("name of hotel "+hotel_name);
        System.out.println("employee id is "+receptionist_id);
    }
}
class Main {
    public static void main(String[] args) {
        Accountant accountant=new Accountant();
        Receptionist receptionist=new Receptionist();
        accountant.method();
        receptionist.method1();
    }
}